"""
created by Jay Nakrani,
           Smitkumar Sukhadiya,
           Hani Kathiriya
"""
"""floor_controller controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot
from controller import Display
from controller import Supervisor

timestep = 12

# create the Robot instance.
robot = Robot()

# create the Robot instance.


#to use in functions
x = 0
y = 1
z = 2

#Size of the ground
x_ground = 10
z_ground = 10

# get the time step of the current world.
#timestep = robot.getBasicTimeStep()

#to init webot stuffs
#robot.__init__()
    
#to assign a handler to devices
display = robot.getDevice("ground_display")
supervisor = robot.getDevice("robot")    
#to get width and height of the display
width = Display.getWidth(display)              #####
height = Display.getHeight(display)            #####
    
#to get the translation field of the robot
robot_node = Supervisor.getFromDef(supervisor, "vacuum_robot")
trans_field = robot_node.getField("translation")
    
#to set the background
background = Display.imageLoad(display, "D:\Vacuum_cleaner\worlds\dirty.jpg")     ######
Display.imagePaste(display, background, 0, 0, blend=False)         ######
    
Display.setAlpha(display, 0.0)
    
while robot.step(timestep) != -1:
    
    translation = trans_field.getSFVec3f()
        
    #to display the robot PositionSensor    ####
    Display.fillOval(display, int(width * (translation[x] + x_ground / 2) / x_ground), int(height * (translation[z] + z_ground / 2) / z_ground), 7, 7)

robot.__del__()  