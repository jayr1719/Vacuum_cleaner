"""controller_for_create controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot
from controller import Receiver
from controller import GPS
import math
import random

timeStep = 12
max_speed = 12
half_speed = 6

start_time = 0
duration = 0

pi = 3.14

wheel_radius = 0.031
axle_length = 0.271756

robot = Robot()

left_wheel = robot.getMotor("left wheel motor")
right_wheel = robot.getMotor("right wheel motor")
"""
cam = robot.getCamera("camera")
cam.enable(timeStep)
cam.recognitionEnable(timeStep)
"""

gps = robot.getGPS("gps")
gps.enable(timeStep)

sensors_on_left = []
sensors_on_right = []
sensors_in_front = []
visited_locations = []
#leds = []

sensors_in_front.append(robot.getDistanceSensor("ps0"))
sensors_in_front[0].enable(timeStep)
sensors_in_front.append(robot.getDistanceSensor("ps7"))
sensors_in_front[1].enable(timeStep)

sensors_on_right.append(robot.getDistanceSensor("ps1"))
sensors_on_right[0].enable(timeStep)
sensors_on_right.append(robot.getDistanceSensor("ps2"))
sensors_on_right[1].enable(timeStep)

sensors_on_left.append(robot.getDistanceSensor("ps6"))
sensors_on_left[0].enable(timeStep)
sensors_on_left.append(robot.getDistanceSensor("ps5"))
sensors_on_left[1].enable(timeStep)

receiver_name = robot.getDevice("receiver")
Receiver.enable(receiver_name, timeStep)

speeds = [max_speed, max_speed] #[left wheel speed, right wheel speed] 

left_wheel.setPosition(float("inf"))
right_wheel.setPosition(float("inf"))
"""
def near_human(position):
    return math.sqrt((position[0] ** 2) + (position[2] ** 2)) < 0.10

def vision_human():
    human = cam.getRecognitionObjects()
    
    h_pos = []
    
    for pos in human:
        if pos.get_colors() == [1, 0, 0]:
            pos1 = pos.get_position()
            h_pos.append(pos1)
    return h_pos
    
def stop_near_human():
    h_pos = vision_human()
    
    for i in h_pos:
        if near_human(i):
            stop()
"""            
def take_right_turn():
    global start_time, duration
    #left wheel speed
    speeds[0] = -0.6 * half_speed
    #right wheel speed
    speeds[1] = 1.2 * half_speed
    
    start_time = robot.getTime()
    duration = 1.4

def take_left_turn():
    global start_time, duration
    #left wheel speed
    speeds[0] = 1.2 * half_speed
    #right wheel speed
    speeds[1] = -0.6 * half_speed
    
    start_time = robot.getTime()
    duration = 1.4
    
def spin():
    global start_time, duration
    #left wheel speed
    speeds[0] = half_speed
    #right wheel speed
    speeds[1] = -half_speed
    
    start_time = robot.getTime()
    duration = random.uniform(2,3)
    
def backward():
    global start_time, duration
    #left wheel speed
    speeds[0] = -half_speed
    #right wheel speed
    speeds[1] = -half_speed
    
    start_time = robot.getTime()
    duration = 1
    
def stop():
    speeds[0] = 0
    speeds[1] = 0
    
def read_rmap():
    while Receiver.getQueueLength(receiver_name)>0:
        Receiver.nextPacket(receiver_name)

while robot.step(timeStep) != -1:
    if robot.getTime() - start_time < duration:
        pass
    else:
        start_time = 0
        duration = 0
        place_pos = 0
        
        speeds[0] = max_speed
        speeds[1] = max_speed        
        """
        l = sensors_on_left[0].getValue()
        l1 = sensors_on_left[1].getValue()
       
        r = sensors_on_right[0].getValue()
        r1 = sensors_on_right[1].getValue()
       
        f = sensors_in_front[0].getValue()
        f1 = sensors_in_front[1].getValue()
        """
        
        ## future enhancement
        
        """
        rob_pos = GPS.getValues(gps)
        if rob_pos in visited_locations:
            print("true")
        """
        
            
        for i in range(2):
            #for the left sensors
            if sensors_on_left[i].getValue() < 390:
                #turn on right angle
                stop()
                print("avoidance in left")
                backward()
                take_right_turn()
                #pass
            elif sensors_on_right[i].getValue() < 390:
                #turn on left side
                stop()
                print("avoidance in right")
                backward()
                take_left_turn()
                #pass
               
        if sensors_in_front[0].getValue() <390 or sensors_in_front[1].getValue() < 390 :
            #move backward
            stop()
            print("avoidance in front")
            backward()
            spin()
        read_rmap()
        #stop_near_human()
        
        ## future enhancement
        #place_pos = GPS.getValues(gps)
        #visited_locations.append(place_pos)
        
        left_wheel.setVelocity(speeds[0])
        right_wheel.setVelocity(speeds[1])