# Here is summary.   
tensorboard --logdir=$R2CNN_HEAD_ROOT/output/res101_summary/   
![01](fast_rcnn_loss.bmp) 
![02](rpn_loss.bmp) 
![03](total_loss.bmp) 